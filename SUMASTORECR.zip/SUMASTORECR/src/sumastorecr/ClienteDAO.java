package sumastorecr;

import java.sql.Connection;
import java.sql.CallableStatement;
import javax.swing.JOptionPane;

public class ClienteDAO {

    public void insertarCliente(String nombre, String contraseña, String correo, String telefono) {
        CallableStatement cs = null;

        try {
            // Obtén la conexión única desde el Singleton
            Connection con = ConexionOracle.getInstance().getConnection();

            // Llamada al procedimiento almacenado
            String sql = "{CALL FIDE_CLIENTES_TB_INSERTAR_CLIENTE_SP(?, ?, ?, ?)}";
            cs = con.prepareCall(sql);

            // Asignación de parámetros
            cs.setString(1, nombre);
            cs.setString(2, correo);
            cs.setString(3, contraseña);
            cs.setString(4, telefono);

            // Ejecutar el procedimiento
            cs.execute();
            System.out.println("Cliente insertado correctamente.");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al insertar cliente: " + e.getMessage());
        } finally {
            try {
                if (cs != null) {
                    cs.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
