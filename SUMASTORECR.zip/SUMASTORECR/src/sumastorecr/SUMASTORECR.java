/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sumastorecr;

import Frames.LoginForm;
import Frames.Registrarse;

/**
 *
 * @author XSF
 */
public class SUMASTORECR {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new LoginForm().setVisible(true);

            java.awt.EventQueue.invokeLater(() -> {
                new Registrarse().setVisible(true);
            });
        });
    }
}
